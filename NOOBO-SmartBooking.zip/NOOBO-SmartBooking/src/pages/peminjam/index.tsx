import { ActivityInformationSection } from "./ActivityInformationSection";
import { ActivityScheduleSection } from "./ActivityScheduleSection";
import { AdditionalInformationSection } from "./AdditionalInformationSection";
import arrow1 from "./arrow-1.svg";
import { BorrowerInformationSection } from "./BorrowerInformationSection";
import { LoanApplicationHeaderSection } from "./LoanApplicationHeaderSection";
import { RequiredFacilitiesSection } from "./RequiredFacilitiesSection";
import vector from "./vector.svg";

export const Fsk = (): JSX.Element => {
  return (
    <main className="bg-[linear-gradient(191deg,rgba(255,255,255,1)_100%,rgba(151,215,255,1)_100%)] w-full min-w-[390px] min-h-[1582px] relative">
      <div
        className="absolute w-full h-[calc(100%_-_137px)] top-[137px] left-0 overflow-hidden overflow-y-scroll"
        role="region"
        aria-label="Formulir pengajuan peminjaman"
      >
        <div className="flex w-full h-[55px] items-center pt-3.5 pb-4 px-5 absolute left-0 bottom-3 bg-[#fffffff2] border-t [border-top-style:solid] border-slate-100 backdrop-blur-[6px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(6px)_brightness(100%)]">
          <button
            type="button"
            className="all-unset box-border flex w-[350px] items-center justify-center px-6 py-3 relative mt-[-9.00px] mb-[-10.00px] bg-blue-600 rounded-xl"
            aria-label="Lanjut ke langkah berikutnya"
          >
            <div className="absolute w-full h-full top-0 left-0 bg-[#ffffff01] rounded-xl shadow-[0px_4px_6px_-4px_#3b82f640,0px_10px_15px_-3px_#3b82f640]" />
            <div className="inline-flex flex-col items-center relative flex-[0_0_auto] ml-[-2.84e-14px]">
              <span className="relative flex items-center justify-center w-fit mt-[-1.00px] [font-family:'Plus_Jakarta_Sans-Bold',Helvetica] font-bold text-white text-sm text-center tracking-[0] leading-5 whitespace-nowrap">
                Lanjut
              </span>
            </div>
            <span className="flex flex-col w-6 h-4 items-start pl-2 pr-0 py-0 relative ml-[-2.84e-14px]">
              <span className="flex flex-col w-4 h-4 items-center justify-center relative">
                <span className="relative flex-1 w-4 grow">
                  <img
                    className="absolute w-[87.50%] h-[81.25%] top-[18.75%] left-[12.50%]"
                    alt=""
                    aria-hidden="true"
                    src={vector}
                  />
                </span>
              </span>
            </span>
          </button>
        </div>
        <BorrowerInformationSection />
        <ActivityInformationSection />
        <RequiredFacilitiesSection />
        <ActivityScheduleSection />
        <AdditionalInformationSection />
      </div>
      <header>
        <LoanApplicationHeaderSection />
        <div className="absolute top-[50px] left-4 w-[255px] h-5 flex gap-[89px]">
          <img
            className="mt-[2.6px] w-4 h-[14.73px] -ml-px"
            alt="Kembali"
            src={arrow1}
          />
          <h1 className="w-[151px] h-5 [font-family:'Plus_Jakarta_Sans-Bold',Helvetica] font-bold text-black text-base tracking-[0] leading-[normal]">
            Ajukan Peminjaman
          </h1>
        </div>
      </header>
    </main>
  );
};
