import ellipse11 from "./ellipse-11.svg";
import ellipse12 from "./ellipse-12.svg";
import ellipse13 from "./ellipse-13.svg";
import ellipse14 from "./ellipse-14.svg";
import line1 from "./line-1.svg";
import line2 from "./line-2.svg";
import line3 from "./line-3.svg";
import line4 from "./line-4.svg";

const steps = [
  {
    number: "1",
    circle: ellipse11,
    position: "left-0",
    numberPosition: "left-3.5",
    active: true,
  },
  {
    number: "2",
    circle: ellipse12,
    position: "left-[100px]",
    numberPosition: "left-28",
    active: false,
  },
  {
    number: "3",
    circle: ellipse13,
    position: "left-[200px]",
    numberPosition: "left-[213px]",
    active: false,
  },
  {
    number: "4",
    circle: ellipse14,
    position: "left-[300px]",
    numberPosition: "left-[312px]",
    active: false,
  },
];

const connectors = [
  {
    source: line1,
    position: "left-[35px]",
    width: "w-8",
  },
  {
    source: line2,
    position: "left-[67px]",
    width: "w-[33px]",
  },
  {
    source: line3,
    position: "left-[135px]",
    width: "w-[65px]",
  },
  {
    source: line4,
    position: "left-[235px]",
    width: "w-[65px]",
  },
];

export const LoanApplicationHeaderSection = (): JSX.Element => {
  return (
    <nav
      className="absolute top-[86px] left-[21px] h-[35px] w-[343px]"
      aria-label="Loan application progress"
    >
      {steps.map((step) => (
        <div key={step.number}>
          <img
            className={`${step.position} absolute top-0 h-[35px] w-[35px]`}
            src={step.circle}
            alt=""
            aria-hidden="true"
          />
          <span
            className={`${step.numberPosition} absolute top-1.5 [font-family:'Poppins-Bold',Helvetica] text-base font-bold tracking-[0] leading-[normal] ${
              step.active ? "text-white" : "text-[#bfbfbf]"
            }`}
            aria-current={step.active ? "step" : undefined}
          >
            {step.number}
          </span>
        </div>
      ))}

      {connectors.map((connector, index) => (
        <img
          key={index}
          className={`${connector.position} ${connector.width} absolute top-[17px] h-px object-cover`}
          src={connector.source}
          alt=""
          aria-hidden="true"
        />
      ))}
    </nav>
  );
};
