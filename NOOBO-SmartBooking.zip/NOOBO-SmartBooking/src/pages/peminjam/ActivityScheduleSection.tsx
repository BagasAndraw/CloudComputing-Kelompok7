import { ChangeEvent, useState } from "react";
import vector11 from "./vector-11.svg";
import vector12 from "./vector-12.svg";
import vector13 from "./vector-13.svg";
import vector14 from "./vector-14.svg";
import vector15 from "./vector-15.svg";
import vector16 from "./vector-16.svg";
import vector17 from "./vector-17.svg";
import vector18 from "./vector-18.svg";
import vector19 from "./vector-19.svg";
import vector20 from "./vector-20.svg";

type TimeField = {
  id: "startTime" | "endTime";
  label: string;
  value: string;
  clockIcon: string;
  leadingIcon: string;
  trailingIcon: string;
};

const timeFields: TimeField[] = [
  {
    id: "startTime",
    label: "Waktu Mulai",
    value: "10.00",
    clockIcon: vector13,
    leadingIcon: vector14,
    trailingIcon: vector16,
  },
  {
    id: "endTime",
    label: "Waktu Selesai",
    value: "16.00",
    clockIcon: vector17,
    leadingIcon: vector18,
    trailingIcon: vector20,
  },
];

export const ActivityScheduleSection = (): JSX.Element => {
  const [activityDate, setActivityDate] = useState("12 Desember 2026");
  const [times, setTimes] = useState<Record<TimeField["id"], string>>({
    startTime: "10.00",
    endTime: "16.00",
  });

  const handleDateChange = (event: ChangeEvent<HTMLInputElement>) => {
    setActivityDate(event.target.value);
  };

  const _handleTimeChange =
    (id: TimeField["id"]) => (event: ChangeEvent<HTMLInputElement>) => {
      setTimes((currentTimes) => ({
        ...currentTimes,
        [id]: event.target.value,
      }));
    };

  return (
    <section
      aria-labelledby="activity-schedule-title"
      className="absolute top-[900px] left-0 flex w-full flex-col items-start gap-4 rounded-2xl border border-solid border-slate-100 bg-slate-50 p-4 shadow-[0px_1px_2px_#0000000d]"
    >
      <header className="relative flex w-full flex-[0_0_auto] items-center">
        <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50">
          <div className="relative h-5 w-5">
            <img
              className="absolute left-[12.50%] top-[12.50%] h-[87.50%] w-[87.50%]"
              src={vector11}
              alt=""
              aria-hidden="true"
            />
          </div>
        </div>
        <div className="relative h-[35.5px] w-[195.8px]">
          <div className="relative -top-px left-3 inline-flex flex-col items-start gap-0.5">
            <h2
              id="activity-schedule-title"
              className="relative mt-[-1.00px] flex w-fit items-center whitespace-nowrap text-sm font-bold leading-[17.5px] tracking-[0] text-slate-900 [font-family:'Plus_Jakarta_Sans-Bold',Helvetica]"
            >
              Jadwal Kegiatan
            </h2>
            <p className="relative mt-[-1.00px] flex w-fit items-center whitespace-nowrap text-xs font-normal leading-4 tracking-[0] text-slate-500 [font-family:'Plus_Jakarta_Sans-Regular',Helvetica]">
              Pilih tanggal dan waktu kegiatan.
            </p>
          </div>
        </div>
      </header>
      <div className="relative flex w-full flex-[0_0_auto] flex-col items-start gap-3.5">
        <div className="relative flex w-full flex-[0_0_auto] flex-col items-start gap-1.5">
          <label
            htmlFor="activity-date"
            className="relative mt-[-1.00px] flex w-full items-center text-xs font-semibold leading-4 tracking-[0] text-slate-700 [font-family:'Plus_Jakarta_Sans-SemiBold',Helvetica]"
          >
            Tanggal Kegiatan
          </label>
          <div className="relative flex w-full flex-[0_0_auto] items-center">
            <input
              id="activity-date"
              name="activityDate"
              type="text"
              value={activityDate}
              onChange={handleDateChange}
              aria-label="Tanggal Kegiatan"
              className="relative min-w-0 flex-1 grow rounded-xl border border-solid border-slate-200 bg-[#f8fafc80] py-2.5 pl-10 pr-3.5 text-sm font-medium leading-5 tracking-[0] text-slate-800 outline-none transition-colors focus:border-blue-400 focus:ring-2 focus:ring-blue-100 [font-family:'Plus_Jakarta_Sans-Medium',Helvetica]"
            />
            <span className="pointer-events-none absolute left-3.5 top-[13px] h-4 w-4">
              <img
                className="absolute left-[12.50%] top-[12.50%] h-[87.50%] w-[87.50%]"
                src={vector12}
                alt=""
                aria-hidden="true"
              />
            </span>
          </div>
        </div>
        <div className="relative flex w-full flex-[0_0_auto] items-start justify-center gap-3">
          {timeFields.map((field) => (
            <div
              key={field.id}
              className="relative flex flex-1 grow flex-col items-start gap-1.5"
            >
              <label
                htmlFor={field.id}
                className="relative mt-[-1.00px] flex w-full items-center self-stretch text-xs font-semibold leading-4 tracking-[0] text-slate-700 [font-family:'Plus_Jakarta_Sans-SemiBold',Helvetica]"
              >
                {field.label}
              </label>
              <div className="relative flex w-full flex-[0_0_auto] items-center">
                <input
                  id={field.id}
                  name={field.id}
                  type="text"
                  inputMode="decimal"
                  value={times[field.id]}
                  aria-label={field.label}
                  className="relative min-w-0 flex-1 grow rounded-xl border border-solid border-slate-200 bg-[#f8fafc80] py-2.5 pl-9 pr-7 text-sm font-medium leading-5 tracking-[0] text-slate-800 outline-none transition-colors focus:border-blue-400 focus:ring-2 focus:ring-blue-100 [font-family:'Plus_Jakarta_Sans-Medium',Helvetica]"
                />
                <span className="pointer-events-none absolute left-3 top-[13px] h-4 w-4">
                  <img
                    className="absolute left-[12.50%] top-[12.50%] h-[87.50%] w-[87.50%]"
                    src={field.leadingIcon}
                    alt=""
                    aria-hidden="true"
                  />
                  <img
                    className="absolute left-[50.00%] top-[25.00%] h-[75.00%] w-[50.00%]"
                    src={field.leadingIcon === vector14 ? vector15 : vector19}
                    alt=""
                    aria-hidden="true"
                  />
                </span>
                <span className="pointer-events-none absolute right-2.5 top-3.5 inline-flex flex-col items-start">
                  <span className="relative h-3.5 w-3.5">
                    <img
                      className="absolute left-[18.75%] top-[34.38%] h-[65.62%] w-[81.25%]"
                      src={field.trailingIcon}
                      alt=""
                      aria-hidden="true"
                    />
                  </span>
                </span>
                <span className="pointer-events-none absolute left-[126px] top-0 flex h-full w-[21px] items-center justify-center">
                  <img
                    className="h-[60.00%] w-[70.00%] translate-x-[30.00%] translate-y-[40.00%]"
                    src={field.clockIcon}
                    alt=""
                    aria-hidden="true"
                  />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
