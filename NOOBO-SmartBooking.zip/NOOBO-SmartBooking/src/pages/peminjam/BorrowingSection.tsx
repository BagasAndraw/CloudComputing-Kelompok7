import { useState } from "react";
import vector2 from "./vector-2.svg";
import vector3 from "./vector-3.svg";
import vector4 from "./vector-4.svg";
import vector5 from "./vector-5.svg";
import vector6 from "./vector-6.svg";

const organizations = [
  "Himpunan Mahasiswa Informatika",
  "Badan Eksekutif Mahasiswa",
  "Unit Kegiatan Mahasiswa",
];

export const BorrowerInformationSection = (): JSX.Element => {
  const [fullName, setFullName] = useState("Brian HUMAS");
  const [organization, setOrganization] = useState(
    "Himpunan Mahasiswa Informatika",
  );
  const [phoneNumber, setPhoneNumber] = useState("8XXXXXXXXXX");

  return (
    <section
      aria-labelledby="borrower-information-title"
      className="flex flex-col w-[390px] h-[792px] items-start gap-4 p-4 absolute top-0 left-0 bg-slate-50 rounded-2xl overflow-hidden border border-solid border-slate-100 shadow-[0px_1px_2px_#0000000d]"
    >
      <header className="flex items-center relative self-stretch w-full flex-[0_0_auto]">
        <div className="flex w-10 h-10 items-center justify-center relative bg-blue-50 rounded-xl">
          <div className="relative w-5 h-5">
            <img
              className="absolute w-[83.33%] h-[83.33%] top-[16.67%] left-[16.67%]"
              alt=""
              src={vector2}
            />
          </div>
        </div>
        <div className="relative w-[258.44px] h-[35.5px]">
          <div className="inline-flex flex-col items-start gap-0.5 relative -top-px left-3">
            <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
              <h2
                id="borrower-information-title"
                className="flex items-center [font-family:'Plus_Jakarta_Sans-Bold',Helvetica] font-bold text-slate-900 text-sm tracking-[0] leading-[17.5px] whitespace-nowrap relative w-fit mt-[-1.00px]"
              >
                Data Peminjam
              </h2>
            </div>
            <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
              <p className="relative flex items-center w-fit mt-[-1.00px] [font-family:'Plus_Jakarta_Sans-Regular',Helvetica] font-normal text-slate-500 text-xs tracking-[0] leading-4 whitespace-nowrap">
                Lengkapi data diri dan organisasi peminjam.
              </p>
            </div>
          </div>
        </div>
      </header>
      <div className="flex flex-col items-start gap-3.5 relative self-stretch w-full flex-[0_0_auto]">
        <div className="flex flex-col items-start gap-1.5 relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
            <label
              htmlFor="borrower-full-name"
              className="relative flex items-center self-stretch mt-[-1.00px] [font-family:'Plus_Jakarta_Sans-SemiBold',Helvetica] font-semibold text-slate-700 text-xs tracking-[0] leading-4"
            >
              Nama Lengkap
            </label>
          </div>
          <div className="flex items-start justify-center px-3.5 py-2.5 relative self-stretch w-full flex-[0_0_auto] bg-[#f8fafc80] rounded-xl overflow-hidden border border-solid border-slate-200">
            <input
              id="borrower-full-name"
              name="fullName"
              type="text"
              value={fullName}
              onChange={(event) => setFullName(event.target.value)}
              className="relative flex items-center self-stretch w-full min-w-0 bg-transparent outline-none [font-family:'Plus_Jakarta_Sans-Medium',Helvetica] font-medium text-slate-800 text-sm tracking-[0] leading-5"
            />
          </div>
        </div>
        <div className="flex flex-col items-start gap-1.5 relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
            <label
              htmlFor="borrower-organization"
              className="relative flex items-center self-stretch mt-[-1.00px] [font-family:'Plus_Jakarta_Sans-SemiBold',Helvetica] font-semibold text-slate-700 text-xs tracking-[0] leading-4"
            >
              Organisasi / Unit Kegiatan
            </label>
          </div>
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
            <div className="items-center pl-3.5 pr-10 py-2.5 self-stretch w-full flex-[0_0_auto] flex justify-center relative bg-[#f8fafc80] rounded-xl border border-solid border-slate-200">
              <div className="flex flex-col w-full h-full items-start justify-center pl-[294px] pr-[9px] py-[10.5px] absolute top-0 left-0 pointer-events-none">
                <div className="relative w-[21px] h-[21px]">
                  <img
                    className="absolute w-[70.00%] h-[60.00%] top-[40.00%] left-[30.00%]"
                    alt=""
                    src={vector3}
                  />
                </div>
              </div>
              <select
                id="borrower-organization"
                name="organization"
                value={organization}
                onChange={(event) => setOrganization(event.target.value)}
                className="relative flex items-center self-stretch mt-[-1.00px] w-full min-w-0 appearance-none bg-transparent outline-none [font-family:'Plus_Jakarta_Sans-Medium',Helvetica] font-medium text-slate-800 text-sm tracking-[0] leading-5"
              >
                {organizations.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>
            <div className="inline-flex h-full items-center pl-0 pr-3 py-0 absolute top-0 right-0 pointer-events-none">
              <div className="relative w-4 h-4">
                <img
                  className="absolute w-[81.25%] h-[65.62%] top-[34.38%] left-[18.75%]"
                  alt=""
                  src={vector4}
                />
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-start gap-1.5 relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
            <label
              htmlFor="borrower-phone"
              className="relative flex items-center self-stretch mt-[-1.00px] [font-family:'Plus_Jakarta_Sans-SemiBold',Helvetica] font-semibold text-slate-700 text-xs tracking-[0] leading-4"
            >
              Nomor WhatsApp
            </label>
          </div>
          <div className="flex items-start relative self-stretch w-full flex-[0_0_auto] bg-[#f8fafc80] rounded-xl overflow-hidden border border-solid border-slate-200">
            <div className="inline-flex items-center px-3 py-0 relative self-stretch flex-[0_0_auto] bg-[#f1f5f999] border-r [border-right-style:solid] border-slate-200">
              <div className="relative w-5 h-3.5">
                <div className="relative w-[93.33%] h-full left-[3.33%]">
                  <img
                    className="absolute w-full h-full top-0 left-0"
                    alt=""
                    src={vector5}
                  />
                  <img
                    className="absolute w-full h-[50.00%] top-[50.00%] left-0"
                    alt=""
                    src={vector6}
                  />
                </div>
              </div>
              <div className="inline-flex flex-col items-start pl-1.5 pr-0 py-0 relative flex-[0_0_auto]">
                <span className="flex items-center [font-family:'Plus_Jakarta_Sans-SemiBold',Helvetica] font-semibold text-slate-600 text-xs tracking-[0] leading-4 whitespace-nowrap relative w-fit mt-[-1.00px]">
                  +62
                </span>
              </div>
            </div>
            <div className="flex flex-col items-start px-3 py-2.5 relative flex-1 self-stretch grow">
              <input
                id="borrower-phone"
                name="phoneNumber"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                value={phoneNumber}
                onChange={(event) => setPhoneNumber(event.target.value)}
                className="relative flex items-center self-stretch w-full min-w-0 bg-transparent outline-none [font-family:'Plus_Jakarta_Sans-Medium',Helvetica] font-medium text-slate-800 text-sm tracking-[0] leading-5"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
