import { useState } from "react";
import vector8 from "./vector-8.svg";
import vector9 from "./vector-9.svg";
import vector10 from "./vector-10.svg";

type Facility = {
  id: string;
  label: JSX.Element;
  checked: boolean;
  wrapperClassName: string;
  checkboxClassName: string;
  textClassName: string;
  icon?: string;
};

const facilities: Facility[] = [
  {
    id: "projector",
    label: <>Proyektor</>,
    checked: true,
    wrapperClassName: "col-[1_/_2] w-full relative row-[1_/_2] h-4",
    checkboxClassName:
      "flex flex-col w-[18px] h-[18px] items-center justify-center absolute top-[calc(50.00%_-_9px)] -left-px bg-[#0b63f6] rounded overflow-hidden border border-solid border-transparent appearance-none cursor-pointer",
    textClassName:
      "inline-flex flex-col items-start pl-2.5 pr-0 py-0 absolute top-0 left-4",
    icon: vector9,
  },
  {
    id: "whiteboard",
    label: <>Papan tulis</>,
    checked: false,
    wrapperClassName:
      "col-[2_/_3] w-[158px] flex items-center relative row-[1_/_2] h-4",
    checkboxClassName:
      "relative w-4 h-4 bg-white rounded border border-solid border-slate-300 appearance-none cursor-pointer checked:bg-[#0b63f6] checked:border-[#0b63f6]",
    textClassName:
      "inline-flex flex-col items-start pl-2.5 pr-0 py-0 relative flex-[0_0_auto]",
  },
  {
    id: "microphone",
    label: (
      <>
        Mikrofon / Sound
        <br />
        System
      </>
    ),
    checked: true,
    wrapperClassName: "relative row-[2_/_3] col-[1_/_2] w-full h-8",
    checkboxClassName:
      "flex flex-col w-[18px] h-[18px] items-center justify-center absolute top-[calc(50.00%_-_9px)] -left-px bg-[#0b63f6] rounded overflow-hidden border border-solid border-transparent appearance-none cursor-pointer",
    textClassName:
      "inline-flex flex-col items-start pl-2.5 pr-[33.92px] py-0 absolute top-0 left-4",
    icon: vector10,
  },
  {
    id: "additional-chairs",
    label: <>Kursi Tambahan</>,
    checked: false,
    wrapperClassName:
      "relative row-[2_/_3] col-[2_/_3] w-[158px] h-8 flex items-center",
    checkboxClassName:
      "relative w-4 h-4 bg-white rounded border border-solid border-slate-300 appearance-none cursor-pointer checked:bg-[#0b63f6] checked:border-[#0b63f6]",
    textClassName:
      "inline-flex flex-col items-start pl-2.5 pr-0 py-0 relative flex-[0_0_auto]",
  },
  {
    id: "walkie-talkie",
    label: <>HT</>,
    checked: false,
    wrapperClassName:
      "relative row-[3_/_4] col-[1_/_2] w-[158px] h-4 flex items-center",
    checkboxClassName:
      "relative w-4 h-4 bg-white rounded border border-solid border-slate-300 appearance-none cursor-pointer checked:bg-[#0b63f6] checked:border-[#0b63f6]",
    textClassName:
      "inline-flex flex-col items-start pl-2.5 pr-0 py-0 relative flex-[0_0_auto]",
  },
  {
    id: "other",
    label: <>Lainnya</>,
    checked: false,
    wrapperClassName:
      "relative row-[3_/_4] col-[2_/_3] w-[158px] h-4 flex items-center",
    checkboxClassName:
      "relative w-4 h-4 bg-white rounded border border-solid border-slate-300 appearance-none cursor-pointer checked:bg-[#0b63f6] checked:border-[#0b63f6]",
    textClassName:
      "inline-flex flex-col items-start pl-2.5 pr-0 py-0 relative flex-[0_0_auto]",
  },
];

export const RequiredFacilitiesSection = (): JSX.Element => {
  const [selectedFacilities, setSelectedFacilities] = useState<
    Record<string, boolean>
  >(() =>
    facilities.reduce<Record<string, boolean>>((selection, facility) => {
      selection[facility.id] = facility.checked;
      return selection;
    }, {}),
  );

  const handleFacilityChange = (id: string): void => {
    setSelectedFacilities((currentSelection) => ({
      ...currentSelection,
      [id]: !currentSelection[id],
    }));
  };

  return (
    <section
      aria-labelledby="required-facilities-title"
      className="flex flex-col w-full items-start gap-4 p-4 absolute top-[688px] left-0 bg-slate-50 rounded-2xl border border-solid border-slate-100 shadow-[0px_1px_2px_#0000000d]"
    >
      <header className="flex items-center relative self-stretch w-full flex-[0_0_auto]">
        <div className="flex w-10 h-10 items-center justify-center relative bg-blue-50 rounded-xl">
          <div className="relative w-5 h-5">
            <img
              className="absolute w-[85.42%] h-[85.42%] top-[14.58%] left-[14.58%]"
              alt=""
              src={vector8}
            />
          </div>
        </div>
        <div className="relative w-[245.19px] h-[35.5px]">
          <div className="inline-flex flex-col items-start gap-0.5 relative -top-px left-3">
            <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
              <h2
                id="required-facilities-title"
                className="flex items-center [font-family:'Plus_Jakarta_Sans-Bold',Helvetica] font-bold text-slate-900 text-sm tracking-[0] leading-[17.5px] whitespace-nowrap relative w-fit mt-[-1.00px]"
              >
                Fasilitas / Barang yang Dibutuhkan
              </h2>
            </div>
            <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto]">
              <p className="flex items-center [font-family:'Plus_Jakarta_Sans-Regular',Helvetica] font-normal text-slate-500 text-xs tracking-[0] leading-4 whitespace-nowrap relative w-fit mt-[-1.00px]">
                Pilih fasilitas atau barang yang diperlukan.
              </p>
            </div>
          </div>
        </div>
      </header>
      <fieldset className="grid grid-cols-2 grid-rows-[16px_32px_16px] h-fit gap-[14px_8px] pt-1 pb-0 px-0 border-0 m-0">
        <legend className="sr-only">Fasilitas yang dibutuhkan</legend>
        {facilities.map((facility) => {
          const isSelected = Boolean(selectedFacilities[facility.id]);

          return (
            <div className={facility.wrapperClassName} key={facility.id}>
              <label htmlFor={`facility-${facility.id}`} className="contents">
                <input
                  id={`facility-${facility.id}`}
                  name="required-facilities"
                  type="checkbox"
                  value={facility.id}
                  checked={isSelected}
                  onChange={() => handleFacilityChange(facility.id)}
                  aria-label={
                    typeof facility.label === "string"
                      ? facility.label
                      : facility.id
                  }
                  className={facility.checkboxClassName}
                />
                {facility.icon && isSelected ? (
                  <span className="pointer-events-none absolute w-4 h-4">
                    <img
                      className="absolute w-[78.05%] h-[71.87%] top-[28.13%] left-[21.95%]"
                      alt=""
                      src={facility.icon}
                    />
                  </span>
                ) : null}
                <span
                  className={`${facility.textClassName} [font-family:'Plus_Jakarta_Sans-Medium',Helvetica] font-medium text-slate-700 text-xs tracking-[0] leading-4`}
                >
                  {facility.label}
                </span>
              </label>
            </div>
          );
        })}
      </fieldset>
    </section>
  );
};
